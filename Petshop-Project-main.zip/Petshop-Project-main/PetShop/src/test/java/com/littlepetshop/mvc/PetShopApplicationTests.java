package com.littlepetshop.mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
